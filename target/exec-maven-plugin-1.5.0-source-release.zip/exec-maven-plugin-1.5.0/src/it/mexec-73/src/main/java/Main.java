import java.io.FileWriter;
import java.io.Writer;
import java.net.URL;

public class Main
{
    public static void main( String[] args ) throws Exception
    {
    }
}
