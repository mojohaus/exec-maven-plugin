package org.codehaus.mojo.exec;

public class Main
{

    // Watch it: no static!!
    public void main( String[] args )
    {
    }
}
